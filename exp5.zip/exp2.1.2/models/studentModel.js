let students = [];
let nextId = 1;

const getStudents = () => students;

const addStudent = (student) => {
    const newStudent = { id: nextId++, name: student.name, age: Number(student.age) };
    students.push(newStudent);
    return newStudent;
};

const getStudentById = (id) => students.find(s => s.id === Number(id));

const updateStudent = (id, data) => {
    const student = getStudentById(id);
    if (!student) return null;
    student.name = data.name !== undefined ? data.name : student.name;
    student.age = data.age !== undefined ? Number(data.age) : student.age;
    return student;
};

const deleteStudent = (id) => {
    const idx = students.findIndex(s => s.id === Number(id));
    if (idx === -1) return null;
    const removed = students.splice(idx, 1)[0];
    return removed;
};

module.exports = { getStudents, addStudent, getStudentById, updateStudent, deleteStudent };