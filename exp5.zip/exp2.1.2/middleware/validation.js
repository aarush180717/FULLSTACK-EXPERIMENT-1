exports.validateStudent = (req, res, next) => {
  const { name, age } = req.body;
  const errors = [];
  if (!name || typeof name !== 'string' || name.trim().length < 3) {
    errors.push('Name is required and must be at least 3 characters');
  }
  const ageNum = Number(age);
  if (!age || Number.isNaN(ageNum) || ageNum < 1 || ageNum > 120) {
    errors.push('Age is required and must be a number between 1 and 120');
  }
  if (errors.length) {
    // Render the appropriate form with errors
    if (req.method === 'POST') {
      return res.status(400).render('new', { errors, old: req.body });
    } else {
      return res.status(400).render('edit', { errors, student: { id: req.params.id, ...req.body } });
    }
  }
  next();
};