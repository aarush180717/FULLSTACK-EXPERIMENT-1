const studentModel = require('../models/studentModel');

exports.showNewForm = (req, res) => {
    // always provide `old` so the template can safely read values
    res.render('new', { errors: [], old: {} });
};

exports.createStudent = (req, res) => {
    const { name, age } = req.body;
    studentModel.addStudent({ name, age });
    res.redirect('/students');
};

exports.listStudents = (req, res) => {
    const students = studentModel.getStudents();
    res.render('students', { students });
};

exports.showEditForm = (req, res, next) => {
    const student = studentModel.getStudentById(req.params.id);
    if (!student) return next(new Error('Student not found'));
    res.render('edit', { student });
};

exports.updateStudent = (req, res, next) => {
    const updated = studentModel.updateStudent(req.params.id, req.body);
    if (!updated) return next(new Error('Student not found'));
    res.redirect('/students');
};

exports.deleteStudent = (req, res, next) => {
    const removed = studentModel.deleteStudent(req.params.id);
    if (!removed) return next(new Error('Student not found'));
    res.redirect('/students');
};