const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const { validateStudent } = require('../middleware/validation');

// RESTful routes
router.get('/', (req, res) => res.redirect('/students'));
router.get('/students', studentController.listStudents);
router.get('/students/new', studentController.showNewForm);
router.post('/students', validateStudent, studentController.createStudent);
router.get('/students/:id/edit', studentController.showEditForm);
router.put('/students/:id', validateStudent, studentController.updateStudent);
router.delete('/students/:id', studentController.deleteStudent);

module.exports = router;