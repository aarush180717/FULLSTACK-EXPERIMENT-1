require('dotenv').config();
const express = require("express");
const { Sequelize } = require("sequelize");
const Product = require("./models/Product");
const productRoutes = require("./routes/productRoutes");

const app = express();

app.use(express.json());

const DB_NAME = process.env.DB_NAME || 'productDB';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASS = process.env.DB_PASS || 'MonsterRex10#';
const DB_HOST = process.env.DB_HOST || 'localhost';

const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASS, {
  host: DB_HOST,
  dialect: "mysql"
});

const startServer = async () => {
  try {
    await sequelize.authenticate();
    console.log("MySQL Connected");

    await sequelize.sync();
    
    app.use("/api/products", productRoutes);

    app.listen(3000, () => {
      console.log("Server running on port 3000");
    });

  } catch (error) {
    console.log(error.message);
  }
};

startServer();