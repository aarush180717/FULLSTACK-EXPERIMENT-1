# Product CRUD Operations with Sequelize & MySQL

A RESTful API for managing products using Node.js, Express.js, and MySQL with Sequelize ORM.

## Setup

### Prerequisites
- Node.js (v14+)
- MySQL server

### Installation
```bash
npm install
```

### Configuration
Update `server.js` and `models/Product.js`:
```javascript
const sequelize = new Sequelize("productDB", "root", "root", {
  host: "localhost",
  dialect: "mysql"
});
```

### Create Database
```sql
CREATE DATABASE productDB;
```

### Start Server
```bash
npm start
```

Server runs on `http://localhost:3000`

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/products` | Create product |
| GET | `/api/products` | Get all products |
| GET | `/api/products/:id` | Get product by ID |
| PUT | `/api/products/:id` | Update product |
| DELETE | `/api/products/:id` | Delete product |
| GET | `/api/products/category/:cat` | Get by category |
| GET | `/api/products/stock/available` | Get in-stock products |
| GET | `/api/products/price?min=X&max=Y` | Get by price range |

---

## Product Schema

| Field | Type | Constraints |
|-------|------|-------------|
| id | Integer | PK, Auto-increment |
| name | String | Required, 3-100 chars |
| price | Decimal | Required, > 0 |
| category | Enum | Electronics, Clothing, Food, Books, Home, Sports, Other |
| description | Text | Max 500 chars |
| inStock | Boolean | Default: true |
| quantity | Integer | Default: 0, >= 0 |
| createdAt | Timestamp | Auto |
| updatedAt | Timestamp | Auto |

---

## Custom Methods

```javascript
// Instance methods
product.isAffordable(budget)
product.updateStock(quantity)
product.getDiscountedPrice(percent)

// Static methods
Product.findByCategory(category)
Product.findInStock()
Product.findByPriceRange(min, max)
```

---

## Example Request

```bash
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Wireless Mouse",
    "price": 29.99,
    "category": "Electronics",
    "quantity": 50
  }'
```

---

## Response Format

```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "Wireless Mouse",
    "price": "29.99",
    "category": "Electronics",
    "inStock": true,
    "quantity": 50,
    "createdAt": "2024-03-15T10:30:00.000Z",
    "updatedAt": "2024-03-15T10:30:00.000Z"
  },
  "message": "Product created successfully"
}
```

---

## Directory Structure

```
exp2.1.1/
├── server.js              # Express & Sequelize setup
├── package.json          # Dependencies
├── controllers/
│   └── productController.js
├── models/
│   └── Product.js
└── routes/
    └── productRoutes.js
```

---

## Course Outcomes

- **CO1**: Backend with Node.js, Express, MySQL
- **CO3**: RESTful APIs with Sequelize ORM
- **CO4**: Validation, error handling, custom methods
