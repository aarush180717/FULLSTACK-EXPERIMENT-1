require('dotenv').config();
const { DataTypes, Op } = require("sequelize");
const { Sequelize } = require("sequelize");

const DB_NAME = process.env.DB_NAME || 'productDB';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASS = process.env.DB_PASS || 'MonsterRex10#';
const DB_HOST = process.env.DB_HOST || 'localhost';

const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASS, {
  host: DB_HOST,
  dialect: "mysql"
});

const Product = sequelize.define("Product", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
    validate: {
      len: [3, 100],
      notEmpty: true
    }
  },
  price: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: false,
    validate: {
      isDecimal: true,
      min: 0.01
    }
  },
  category: {
    type: DataTypes.ENUM("Electronics", "Clothing", "Food", "Books", "Home", "Sports", "Other"),
    allowNull: false
  },
  description: {
    type: DataTypes.TEXT,
    validate: {
      len: [0, 500]
    }
  },
  inStock: {
    type: DataTypes.BOOLEAN,
    defaultValue: true
  },
  quantity: {
    type: DataTypes.INTEGER,
    defaultValue: 0,
    validate: {
      min: 0
    }
  }
}, {
  timestamps: true,
  tableName: "products"
});

Product.prototype.isAffordable = function(budget) {
  return this.price <= budget;
};

Product.prototype.updateStock = function(qty) {
  this.quantity = qty;
  this.inStock = qty > 0;
  return this.save();
};

Product.prototype.getDiscountedPrice = function(discountPercent) {
  return (this.price * (100 - discountPercent)) / 100;
};

Product.findByCategory = function(category) {
  return this.findAll({ where: { category: category } });
};

Product.findInStock = function() {
  return this.findAll({ where: { inStock: true } });
};

Product.findByPriceRange = function(minPrice, maxPrice) {
  return this.findAll({
    where: {
      price: {
        [Op.gte]: minPrice,
        [Op.lte]: maxPrice
      }
    }
  });
};

module.exports = Product;