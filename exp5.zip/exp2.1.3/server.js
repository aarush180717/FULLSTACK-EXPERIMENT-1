const express = require('express');
require('dotenv').config();
const productRoutes = require('./routes/productRoutes');

const app = express();
app.use(express.json());

require('./models')
  .then(db => {
    const { sequelize } = db;
    return sequelize.authenticate()
      .then(() => console.log('MySQL connected'))
      .then(() => sequelize.sync({ alter: true }))
      .then(() => console.log('Database synced'))
      .then(() => {
        app.use('/api/products', productRoutes);
        const PORT = process.env.PORT || 4000;
        app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
      });
  })
  .catch(err => console.error('DB init error', err));
