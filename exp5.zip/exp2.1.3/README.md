E-commerce Catalog (exp2.1.3)

Endpoints:
- POST /api/products    -> create product
- GET  /api/products    -> list products
- GET  /api/products/:id -> get product
- PUT  /api/products/:id -> update product
- DELETE /api/products/:id -> delete product
- POST /api/products/:id/stock -> update sku stock { sku, delta }
- POST /api/products/:id/reviews -> add review { userId, rating, comment }
- GET  /api/products/agg/avg-by-category -> aggregation of avg rating per category

Model supports nested `variants` and `reviews`. Use MongoDB at mongodb://127.0.0.1:27017/ecom_catalog
