const express = require('express');
const router = express.Router();
const ctrl = require('../controllers/productController');

router.post('/', ctrl.createProduct);
router.get('/', ctrl.getProducts);
router.get('/agg/avg-by-category', ctrl.avgRatingByCategory);
router.get('/:id', ctrl.getProduct);
router.put('/:id', ctrl.updateProduct);
router.delete('/:id', ctrl.deleteProduct);

router.post('/:id/stock', ctrl.updateStock);
router.post('/:id/reviews', ctrl.addReview);

module.exports = router;
