module.exports = (sequelize, DataTypes) => {
  const Variant = sequelize.define('Variant', {
    id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
    sku: { type: DataTypes.STRING, allowNull: false },
    color: { type: DataTypes.STRING },
    price: { type: DataTypes.FLOAT, allowNull: false, defaultValue: 0 },
    stock: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
    productId: { type: DataTypes.INTEGER.UNSIGNED, allowNull: false }
  }, {
    tableName: 'variants',
    timestamps: false
  });

  return Variant;
};
