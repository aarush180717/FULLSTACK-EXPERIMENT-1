module.exports = (sequelize, DataTypes) => {
  const Product = sequelize.define('Product', {
    id: { type: DataTypes.INTEGER.UNSIGNED, autoIncrement: true, primaryKey: true },
    name: { type: DataTypes.STRING, allowNull: false },
    category: { type: DataTypes.STRING, allowNull: false },
    avgRating: { type: DataTypes.FLOAT, allowNull: true },
    createdAt: { type: DataTypes.DATE, allowNull: false, defaultValue: DataTypes.NOW }
  }, {
    tableName: 'products',
    timestamps: false,
    indexes: [
      { fields: ['category'] },
      { fields: ['avgRating'] }
    ]
  });

  Product.prototype.updateStock = async function(sku, delta) {
    const { Variant } = sequelize.models;
    const variant = await Variant.findOne({ where: { sku, productId: this.id } });
    if (!variant) throw new Error('Variant not found');
    variant.stock = Math.max(0, variant.stock + delta);
    await variant.save();
    return variant.stock;
  };

  Product.prototype.addReview = async function(review) {
    const { Review } = sequelize.models;
    await Review.create({ ...review, productId: this.id });
    const avg = await Product.recomputeAvg(this.id);
    this.avgRating = avg;
    await this.save();
    return avg;
  };

  Product.recomputeAvg = async function(productId) {
    const { Review } = sequelize.models;
    const rows = await Review.findAll({ where: { productId }, attributes: ['rating'] });
    if (!rows.length) return null;
    const total = rows.reduce((s, r) => s + r.rating, 0);
    return total / rows.length;
  };

  Product.avgRatingByCategory = async function() {
    const [results] = await sequelize.query(
      `SELECT p.category, AVG(r.rating) as avgCategoryRating
       FROM products p
       JOIN reviews r ON p.id = r.productId
       GROUP BY p.category`);
    return results;
  };

  return Product;
};
