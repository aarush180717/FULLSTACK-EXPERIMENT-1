const { Sequelize, DataTypes } = require('sequelize');
const mysql = require('mysql2/promise');
require('dotenv').config();

const DB_NAME = process.env.DB_NAME || 'ecom_catalog_mysql';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASS = process.env.DB_PASS || 'MonsterRex10#';
const DB_HOST = process.env.DB_HOST || '127.0.0.1';
const DB_DIALECT = 'mysql';

async function makeSequelize() {
  try {
    const conn = await mysql.createConnection({ host: DB_HOST, user: DB_USER, password: DB_PASS });
    await conn.query(`CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\`;`);
    await conn.end();
  } catch (err) {
    console.error('Could not create database', err.message);
  }

  const sequelize = new Sequelize(DB_NAME, DB_USER, DB_PASS, {
    host: DB_HOST,
    dialect: DB_DIALECT,
    logging: false
  });

  const db = { sequelize, DataTypes };

  db.Product = require('./product')(sequelize, DataTypes);
  db.Variant = require('./variant')(sequelize, DataTypes);
  db.Review = require('./review')(sequelize, DataTypes);

  db.Product.hasMany(db.Variant, { as: 'variants', foreignKey: 'productId', onDelete: 'CASCADE' });
  db.Variant.belongsTo(db.Product, { foreignKey: 'productId' });

  db.Product.hasMany(db.Review, { as: 'reviews', foreignKey: 'productId', onDelete: 'CASCADE' });
  db.Review.belongsTo(db.Product, { foreignKey: 'productId' });

  return db;
}

module.exports = makeSequelize();
