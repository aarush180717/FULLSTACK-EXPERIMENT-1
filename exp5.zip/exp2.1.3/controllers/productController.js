exports.createProduct = async (req, res) => {
  const { Product, Variant } = await require('../models');
  try {
    const { name, category, variants } = req.body;
    const product = await Product.create({ name, category });
    if (Array.isArray(variants) && variants.length) {
      const toCreate = variants.map(v => ({ ...v, productId: product.id }));
      await Variant.bulkCreate(toCreate);
    }
    const created = await Product.findByPk(product.id, { include: ['variants', 'reviews'] });
    res.status(201).json(created);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getProducts = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const products = await Product.findAll({ include: ['variants', 'reviews'] });
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getProduct = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const p = await Product.findByPk(req.params.id, { include: ['variants', 'reviews'] });
    if (!p) return res.status(404).json({ error: 'Not found' });
    res.json(p);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateProduct = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const p = await Product.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: 'Not found' });
    await p.update(req.body);
    const updated = await Product.findByPk(p.id, { include: ['variants', 'reviews'] });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteProduct = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const p = await Product.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: 'Not found' });
    await p.destroy();
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.updateStock = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const { id } = req.params;
    const { sku, delta } = req.body;
    const product = await Product.findByPk(id);
    if (!product) return res.status(404).json({ error: 'Not found' });
    const newStock = await product.updateStock(sku, Number(delta));
    res.json({ sku, stock: newStock });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.addReview = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const { id } = req.params;
    const { userId, rating, comment } = req.body;
    const product = await Product.findByPk(id);
    if (!product) return res.status(404).json({ error: 'Not found' });
    const avg = await product.addReview({ userId, rating: Number(rating), comment });
    res.json({ avgRating: avg });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.avgRatingByCategory = async (req, res) => {
  const { Product } = await require('../models');
  try {
    const result = await Product.avgRatingByCategory();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
